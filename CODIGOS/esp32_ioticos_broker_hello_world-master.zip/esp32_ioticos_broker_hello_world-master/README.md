# esp32_ioticos_broker_hello_world

Código del video: https://youtu.be/1ALkBPEFyN8
